
  # 3D Business Card (Community)

  This is a code bundle for 3D Business Card (Community). The original project is available at https://www.figma.com/design/a4lE4Ey5rAW0PwucMs5mhk/3D-Business-Card--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  